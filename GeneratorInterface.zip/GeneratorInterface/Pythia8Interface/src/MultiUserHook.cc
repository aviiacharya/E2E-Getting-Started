#include "Pythia8/Pythia.h"
#include "GeneratorInterface/Pythia8Interface/interface/MultiUserHook.h"

using namespace Pythia8;
